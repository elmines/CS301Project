﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UAMovie.Models;

namespace UAMovie.Models.ViewModels
{
    public class SystemInfoAccountUser
    {
        public AccountUser user { get; set; }
        public SystemInfo info { get; set; }
    }
}

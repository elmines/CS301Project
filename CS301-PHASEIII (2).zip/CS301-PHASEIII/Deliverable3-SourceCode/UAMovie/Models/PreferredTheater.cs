﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UAMovie.Models
{
    public class PreferredTheater
    {
        public String TheaterID { get; set; }
        public String Username { get; set; }
    }
}
